const STAGES = [
  {
    id: 'prepare',
    step: '01',
    title: 'Prepare',
    detail: 'Set output folder and select documents',
  },
  {
    id: 'ocr',
    step: '02',
    title: 'OCR',
    detail: 'Extract text and save Markdown',
  },
  {
    id: 'report',
    step: '03',
    title: 'Report',
    detail: 'Generate Excel and refine fields',
  },
];

function stageClass(id, activeStage, prepareDone, ocrDone) {
  if (id === activeStage) return 'is-active';
  if (id === 'prepare' && prepareDone) return 'is-done';
  if (id === 'ocr' && ocrDone) return 'is-done';
  return '';
}

export default function WorkflowSteps({ activeStage, prepareDone, ocrDone }) {
  return (
    <nav className="stage-rail workspace-enter" aria-label="Workflow stages">
      {STAGES.map((stage) => {
        const cls = stageClass(stage.id, activeStage, prepareDone, ocrDone);
        return (
          <div key={stage.id} className={`stage-card ${cls}`.trim()}>
            <div className="flex items-baseline justify-between gap-2 mb-1">
              <span className="text-[0.68rem] font-semibold tracking-[0.14em] uppercase text-[var(--color-muted)]">
                Stage {stage.step}
              </span>
              {cls === 'is-done' && (
                <span className="text-[0.68rem] font-semibold text-[var(--color-accent)]">Done</span>
              )}
              {cls === 'is-active' && (
                <span className="text-[0.68rem] font-semibold text-[var(--color-accent)]">
                  Current
                </span>
              )}
            </div>
            <p
              className="text-[1.05rem] font-[560] text-[var(--color-ink)] tracking-[-0.02em]"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {stage.title}
            </p>
            <p className="text-xs text-[var(--color-muted)] mt-1 leading-snug">{stage.detail}</p>
          </div>
        );
      })}
    </nav>
  );
}
