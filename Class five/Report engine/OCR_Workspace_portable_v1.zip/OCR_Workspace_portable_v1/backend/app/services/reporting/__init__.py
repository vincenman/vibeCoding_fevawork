"""Orchestrate OCR Markdown → Excel reporting."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from app.services.reporting.excel_service import update_excel, write_excel
from app.services.reporting.extractor import extract_fields_from_md, get_azure_client
from app.services.reporting.md_resolver import resolve_md_files
from app.services.reporting.prompts import EXTRACT_FIELDS, SYSTEM_PROMPT
from app.services.reporting.telegram_service import send_excel_via_telegram


@dataclass
class ReportRunResult:
    excel_path: str
    columns: list[str]
    rows: list[dict[str, str]]
    row_count: int
    model: str
    telegram_sent: bool
    telegram_message: str
    source_files: list[str]


def run_report(
    md_folder: Path,
    excel_path: Path,
    filenames: list[str] | None = None,
    send_telegram: bool = True,
    telegram_token: str | None = None,
    telegram_chat_id: str | None = None,
) -> ReportRunResult:
    md_paths = resolve_md_files(md_folder, filenames)
    client, model = get_azure_client()

    rows: list[dict[str, str]] = []
    for md_path in md_paths:
        rows.append(
            extract_fields_from_md(
                client,
                model,
                md_path,
                system_prompt=SYSTEM_PROMPT,
                fields=EXTRACT_FIELDS,
            )
        )

    write_excel(rows, excel_path, columns=EXTRACT_FIELDS)

    telegram_sent = False
    telegram_message = "Telegram not requested."
    if send_telegram:
        # Caller may await separately; sync path uses asyncio in route layer.
        # Here we only prepare; telegram is sent asynchronously by the API route.
        telegram_message = "Pending Telegram send."

    return ReportRunResult(
        excel_path=str(excel_path),
        columns=list(EXTRACT_FIELDS),
        rows=rows,
        row_count=len(rows),
        model=model,
        telegram_sent=telegram_sent,
        telegram_message=telegram_message,
        source_files=[path.name for path in md_paths],
    )


async def run_report_async(
    md_folder: Path,
    excel_path: Path,
    filenames: list[str] | None = None,
    send_telegram: bool = True,
    telegram_token: str | None = None,
    telegram_chat_id: str | None = None,
) -> ReportRunResult:
    import asyncio

    result = await asyncio.to_thread(
        run_report,
        md_folder,
        excel_path,
        filenames,
        False,  # telegram handled below
        telegram_token,
        telegram_chat_id,
    )

    if send_telegram:
        sent, message = await send_excel_via_telegram(
            excel_path=excel_path,
            row_count=result.row_count,
            token=telegram_token,
            chat_id=telegram_chat_id,
        )
        result.telegram_sent = sent
        result.telegram_message = message
    else:
        result.telegram_message = "Telegram skipped by request."

    return result


def save_updated_report(
    excel_path: Path,
    columns: list[str],
    rows: list[dict],
) -> str:
    update_excel(excel_path, columns=columns, rows=rows)
    return str(excel_path)
