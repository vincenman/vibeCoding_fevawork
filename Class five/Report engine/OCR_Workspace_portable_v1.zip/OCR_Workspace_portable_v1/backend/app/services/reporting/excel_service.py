"""Excel read/write helpers for OCR reports."""

from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from app.services.reporting.prompts import EXTRACT_FIELDS


def write_excel(
    rows: list[dict],
    output_path: Path,
    columns: list[str] | None = None,
) -> Path:
    cols = columns or EXTRACT_FIELDS
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "OCR Report"

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="1F4E79")
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for col, field in enumerate(cols, start=1):
        cell = sheet.cell(row=1, column=col, value=field)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    wrap = Alignment(vertical="top", wrap_text=True)
    for row_idx, row in enumerate(rows, start=2):
        for col, field in enumerate(cols, start=1):
            cell = sheet.cell(row=row_idx, column=col, value=row.get(field, ""))
            cell.alignment = wrap

    sheet.auto_filter.ref = sheet.dimensions
    sheet.freeze_panes = "A2"
    sheet.row_dimensions[1].height = 22

    for col, field in enumerate(cols, start=1):
        values = [field] + [str(row.get(field, "")) for row in rows]
        width = min(max(len(value) for value in values) + 2, 50)
        sheet.column_dimensions[get_column_letter(col)].width = max(width, 14)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(output_path)
    return output_path


def read_excel(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    workbook = load_workbook(path, data_only=True)
    sheet = workbook.active
    if sheet.max_row < 1:
        return [], []

    columns = [
        str(sheet.cell(row=1, column=col).value or f"col_{col}")
        for col in range(1, sheet.max_column + 1)
    ]
    rows: list[dict[str, str]] = []
    for row_idx in range(2, sheet.max_row + 1):
        row = {
            columns[col - 1]: str(sheet.cell(row=row_idx, column=col).value or "")
            for col in range(1, sheet.max_column + 1)
        }
        rows.append(row)
    return columns, rows


def update_excel(
    path: Path,
    columns: list[str],
    rows: list[dict],
) -> Path:
    """Overwrite workbook contents with edited table data."""
    return write_excel(rows=rows, output_path=path, columns=columns)
