"""API routes for OCR Excel reporting engine."""

from pathlib import Path

from fastapi import APIRouter, HTTPException

from app.config import settings
from app.models.schemas import (
    ReportRunRequest,
    ReportRunResponse,
    ReportUpdateRequest,
    ReportUpdateResponse,
)
from app.services.reporting import run_report_async, save_updated_report
from app.utils.path_utils import PathValidationError, normalize_output_folder

router = APIRouter(prefix="/report", tags=["report"])


def _sanitize_excel_filename(name: str) -> str:
    cleaned = Path(name or "").name.strip()
    if not cleaned:
        cleaned = settings.default_excel_filename
    if not cleaned.lower().endswith(".xlsx"):
        cleaned = f"{cleaned}.xlsx"
    return cleaned


@router.post("/run", response_model=ReportRunResponse)
async def run_report(body: ReportRunRequest):
    try:
        md_folder = normalize_output_folder(body.md_folder)
    except PathValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    excel_folder_raw = body.excel_folder or body.md_folder
    try:
        excel_folder = normalize_output_folder(excel_folder_raw)
    except PathValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    excel_filename = _sanitize_excel_filename(
        body.excel_filename or settings.default_excel_filename
    )
    excel_path = excel_folder / excel_filename

    try:
        result = await run_report_async(
            md_folder=md_folder,
            excel_path=excel_path,
            filenames=body.md_filenames or None,
            send_telegram=body.send_telegram,
        )
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Report generation failed: {exc}",
        ) from exc

    return ReportRunResponse(
        excel_path=result.excel_path,
        columns=result.columns,
        rows=result.rows,
        row_count=result.row_count,
        model=result.model,
        source_files=result.source_files,
        telegram_sent=result.telegram_sent,
        telegram_message=result.telegram_message,
    )


@router.post("/update", response_model=ReportUpdateResponse)
async def update_report(body: ReportUpdateRequest):
    if not body.columns:
        raise HTTPException(status_code=400, detail="columns are required")
    if body.rows is None:
        raise HTTPException(status_code=400, detail="rows are required")

    excel_path = Path(body.excel_path).expanduser().resolve()
    if ".." in body.excel_path:
        raise HTTPException(status_code=400, detail="Path traversal (..) is not allowed")

    if not excel_path.parent.exists():
        raise HTTPException(
            status_code=400,
            detail=f"Excel folder does not exist: {excel_path.parent}",
        )

    # Reuse folder writability checks
    try:
        normalize_output_folder(str(excel_path.parent))
    except PathValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    try:
        saved = save_updated_report(
            excel_path=excel_path,
            columns=body.columns,
            rows=body.rows,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to update Excel: {exc}",
        ) from exc

    return ReportUpdateResponse(
        excel_path=saved,
        row_count=len(body.rows),
        message="Excel updated successfully",
    )
