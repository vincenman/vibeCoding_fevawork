import { useMemo, useState } from 'react';
import { runReport, updateReport } from '../api/client';

const DEFAULT_EXCEL_NAME = 'OCR_report_v1.xlsx';

export default function ReportPanel({ mdFolder, disabled }) {
  const [excelFilename, setExcelFilename] = useState(DEFAULT_EXCEL_NAME);
  const [running, setRunning] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [error, setError] = useState(null);
  const [status, setStatus] = useState(null);
  const [excelPath, setExcelPath] = useState(null);
  const [columns, setColumns] = useState([]);
  const [rows, setRows] = useState([]);
  const [dirty, setDirty] = useState(false);
  const [justSaved, setJustSaved] = useState(false);

  const canRun = mdFolder.trim().length > 0 && !disabled && !running && !updating;
  const canUpdate = Boolean(excelPath) && rows.length > 0 && !running && !updating;

  const hasTable = columns.length > 0 && rows.length > 0;

  const sourceSummary = useMemo(() => {
    if (!rows.length) return '';
    return `${rows.length} row${rows.length === 1 ? '' : 's'} · ${columns.length} fields`;
  }, [rows, columns]);

  const handleRun = async () => {
    if (!mdFolder.trim()) {
      setError('Enter an output / Markdown folder path first');
      return;
    }

    setRunning(true);
    setError(null);
    setStatus('Running reporting engine…');
    setDirty(false);
    setJustSaved(false);

    try {
      const data = await runReport({
        md_folder: mdFolder.trim(),
        excel_folder: mdFolder.trim(),
        excel_filename: excelFilename.trim() || DEFAULT_EXCEL_NAME,
        send_telegram: true,
      });
      setColumns(data.columns || []);
      setRows((data.rows || []).map((row) => ({ ...row })));
      setExcelPath(data.excel_path);
      setStatus(
        `Report ready (${data.row_count} row(s)). ${data.telegram_message || ''}`.trim(),
      );
      setJustSaved(true);
      window.setTimeout(() => setJustSaved(false), 1200);
    } catch (err) {
      setError(err.message || 'Report generation failed');
      setStatus(null);
    } finally {
      setRunning(false);
    }
  };

  const handleCellChange = (rowIndex, column, value) => {
    setRows((prev) =>
      prev.map((row, idx) => (idx === rowIndex ? { ...row, [column]: value } : row)),
    );
    setDirty(true);
  };

  const handleUpdateExcel = async () => {
    if (!excelPath) return;

    setUpdating(true);
    setError(null);
    setStatus('Saving Excel updates…');

    try {
      const data = await updateReport({
        excel_path: excelPath,
        columns,
        rows,
      });
      setDirty(false);
      setStatus(`Excel updated: ${data.excel_path}`);
      setJustSaved(true);
      window.setTimeout(() => setJustSaved(false), 1200);
    } catch (err) {
      setError(err.message || 'Failed to update Excel');
    } finally {
      setUpdating(false);
    }
  };

  return (
    <section className={`panel workspace-enter workspace-enter-delay-2 ${justSaved ? 'success-pulse' : ''}`}>
      <div className="flex flex-wrap items-start justify-between gap-3 mb-5">
        <div>
          <h2 className="panel-title">Report engine</h2>
          <p className="panel-subtitle">
            Extract structured invoice fields from Markdown into an editable Excel workbook.
          </p>
        </div>
        <button
          type="button"
          onClick={handleRun}
          disabled={!canRun}
          className="btn-primary min-w-[11rem]"
        >
          {running ? 'Generating…' : 'Generate Excel report'}
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 mb-4">
        <div>
          <label className="block text-sm font-medium text-[var(--color-ink-soft)] mb-1.5">
            Markdown folder
          </label>
          <input
            type="text"
            value={mdFolder}
            readOnly
            className="field-input field-input-readonly"
          />
          <p className="mt-1 text-xs text-[var(--color-muted)]">
            Uses the OCR output folder (must contain .md files).
          </p>
        </div>
        <div>
          <label
            htmlFor="excel-filename"
            className="block text-sm font-medium text-[var(--color-ink-soft)] mb-1.5"
          >
            Excel filename
          </label>
          <input
            id="excel-filename"
            type="text"
            value={excelFilename}
            onChange={(e) => setExcelFilename(e.target.value)}
            disabled={disabled || running || updating}
            className="field-input"
          />
        </div>
      </div>

      {!mdFolder.trim() && (
        <div className="alert alert-warn mb-3">
          Set an output folder in Stage 01 before generating a report.
        </div>
      )}

      {error && <div className="alert alert-danger mb-3">{error}</div>}

      {status && (
        <div className="alert alert-ok mb-3">
          <div className="flex flex-wrap items-center gap-2">
            <span>{status}</span>
            {dirty && (
              <span className="text-[0.68rem] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-md bg-[var(--color-warn-soft)] text-[var(--color-warn)]">
                Unsaved edits
              </span>
            )}
          </div>
          {excelPath && (
            <p className="mt-1 font-mono text-[0.72rem] break-all opacity-90">{excelPath}</p>
          )}
        </div>
      )}

      {hasTable && (
        <>
          <div className="flex items-center justify-between gap-3 mb-3 flex-wrap">
            <p className="text-sm text-[var(--color-muted)]">
              {sourceSummary} — edit cells, then save
            </p>
            <button
              type="button"
              onClick={handleUpdateExcel}
              disabled={!canUpdate}
              className="btn-secondary"
            >
              {updating ? 'Updating…' : 'Update Excel'}
            </button>
          </div>

          <div className="report-table-wrap">
            <div className="report-table-scroll">
              <table className="report-table">
                <thead>
                  <tr>
                    <th className="!min-w-[2.5rem]">#</th>
                    {columns.map((col) => (
                      <th key={col}>{col}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, rowIndex) => (
                    <tr key={`row-${rowIndex}`}>
                      <td className="!min-w-[2.5rem] text-[var(--color-muted)] font-medium px-2 py-2">
                        {rowIndex + 1}
                      </td>
                      {columns.map((col) => (
                        <td key={`${rowIndex}-${col}`}>
                          <textarea
                            value={row[col] ?? ''}
                            onChange={(e) => handleCellChange(rowIndex, col, e.target.value)}
                            rows={2}
                            className="report-cell"
                          />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </section>
  );
}
