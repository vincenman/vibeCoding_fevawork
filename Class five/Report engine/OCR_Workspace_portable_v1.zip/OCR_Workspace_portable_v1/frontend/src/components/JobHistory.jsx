import { useEffect, useState } from 'react';
import { fetchJobs } from '../api/client';

export default function JobHistory({ refreshKey }) {
  const [jobs, setJobs] = useState([]);
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    fetchJobs()
      .then(setJobs)
      .catch(() => setJobs([]));
  }, [refreshKey]);

  if (jobs.length === 0) return null;

  return (
    <section className="panel">
      <h2 className="panel-title mb-1">Recent jobs</h2>
      <p className="panel-subtitle mb-4">Latest OCR runs from this backend session.</p>
      <ul className="divide-y divide-[var(--color-line)]">
        {jobs.map((job) => (
          <li key={job.job_id} className="py-3">
            <button
              type="button"
              onClick={() => setExpanded(expanded === job.job_id ? null : job.job_id)}
              className="w-full text-left flex items-center justify-between gap-3"
            >
              <div>
                <span className="text-sm font-mono text-[var(--color-ink-soft)]">
                  {job.job_id.slice(0, 8)}…
                </span>
                <span className="ml-2 text-xs text-[var(--color-muted)]">
                  {job.file_count} file(s)
                </span>
              </div>
              <span
                className={`text-[0.68rem] font-semibold px-2 py-0.5 rounded-md uppercase tracking-wide ${
                  job.status === 'completed'
                    ? 'bg-[var(--color-ok-soft)] text-[var(--color-ok)]'
                    : job.status === 'failed'
                      ? 'bg-[var(--color-danger-soft)] text-[var(--color-danger)]'
                      : 'bg-[var(--color-warn-soft)] text-[var(--color-warn)]'
                }`}
              >
                {job.status}
              </span>
            </button>
            {expanded === job.job_id && (
              <div className="mt-2 text-xs text-[var(--color-muted)] space-y-1">
                <p>Created: {new Date(job.created_at).toLocaleString()}</p>
                {job.md_files?.length > 0 && (
                  <ul className="space-y-1">
                    {job.md_files.map((path) => (
                      <li key={path} className="font-mono break-all">
                        MD: {path}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}
