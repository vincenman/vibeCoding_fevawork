import { useEffect, useMemo, useRef, useState } from 'react';
import { uploadAndOcr } from './api/client';
import OutputPathForm from './components/OutputPathForm';
import UploadZone from './components/UploadZone';
import ProgressBar from './components/ProgressBar';
import ProcessingStatus from './components/ProcessingStatus';
import ResultsViewer from './components/ResultsViewer';
import ReportPanel from './components/ReportPanel';
import JobHistory from './components/JobHistory';
import WorkflowSteps from './components/WorkflowSteps';

const STORAGE_KEY = 'ocr_output_folder';
const SUPPORTED_FILE_RE = /\.(png|jpe?g|webp|tiff?|pdf)$/i;

function filterSupportedFiles(files) {
  return files.filter((f) => SUPPORTED_FILE_RE.test(f.name));
}

function formatBytes(size) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

export default function App() {
  const [outputFolder, setOutputFolder] = useState(
    () => localStorage.getItem(STORAGE_KEY) || '',
  );
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [selectionMessage, setSelectionMessage] = useState('');
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(null);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const progressSectionRef = useRef(null);

  useEffect(() => {
    if (!processing) return;
    progressSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, [processing]);

  const prepareDone = outputFolder.trim().length > 0 && selectedFiles.length > 0;
  const ocrDone = Boolean(result?.status === 'completed' || result?.md_files?.length);

  const activeStage = useMemo(() => {
    if (processing) return 'ocr';
    if (ocrDone) return 'report';
    if (prepareDone) return 'ocr';
    return 'prepare';
  }, [processing, ocrDone, prepareDone]);

  const handleOutputFolderChange = (value) => {
    setOutputFolder(value);
    if (value.trim()) localStorage.setItem(STORAGE_KEY, value);
  };

  const handleFilesSelected = (files) => {
    const allFiles = Array.from(files);
    const supported = filterSupportedFiles(allFiles);

    if (allFiles.length === 0) {
      setSelectionMessage('');
      setSelectedFiles([]);
    } else if (supported.length === 0) {
      setSelectionMessage(
        `No supported files found among ${allFiles.length} selected. Use PNG, JPG, WEBP, TIFF, or PDF.`,
      );
      setSelectedFiles([]);
    } else if (supported.length < allFiles.length) {
      setSelectionMessage(
        `Using ${supported.length} supported file(s); skipped ${allFiles.length - supported.length} unsupported file(s).`,
      );
      setSelectedFiles(supported);
    } else {
      setSelectionMessage('');
      setSelectedFiles(supported);
    }

    setResult(null);
    setError(null);
  };

  const canStart = outputFolder.trim().length > 0 && selectedFiles.length > 0 && !processing;

  const handleStartOcr = async () => {
    if (!outputFolder.trim()) {
      setError('Please enter an output folder path');
      return;
    }
    if (selectedFiles.length === 0) {
      setError('Please select at least one supported file');
      return;
    }

    setProcessing(true);
    setError(null);
    setResult(null);
    setProgress({
      stage: 'uploading',
      percent: 5,
      total_files: selectedFiles.length,
      current_file: 0,
      message: 'Uploading files…',
    });

    try {
      const data = await uploadAndOcr(
        selectedFiles,
        outputFolder.trim(),
        (progressUpdate) => {
          if (progressUpdate) setProgress(progressUpdate);
        },
      );
      setResult(data);
      setProgress(
        data.progress || { stage: 'completed', percent: 100, message: 'OCR job completed' },
      );
      setRefreshKey((k) => k + 1);
    } catch (err) {
      setError(err.message || 'OCR request failed');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="min-h-screen">
      <header className="border-b border-[var(--color-line)] bg-[rgba(255,255,255,0.82)] backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-6 py-7">
          <p className="text-[0.68rem] font-semibold tracking-[0.16em] uppercase text-[var(--color-accent)] mb-2">
            Document intelligence
          </p>
          <h1
            className="text-[2rem] sm:text-[2.35rem] font-[680] tracking-[-0.03em] text-[var(--color-ink)] leading-tight"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            OCR Workspace
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-2 max-w-2xl leading-relaxed">
            Extract text from images and PDFs, save Markdown, then generate and refine structured
            Excel reports in one continuous flow.
          </p>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-8 space-y-6">
        <WorkflowSteps
          activeStage={activeStage}
          prepareDone={prepareDone}
          ocrDone={ocrDone}
        />

        <div className="workspace-enter workspace-enter-delay-1 space-y-6">
          <section className="space-y-3">
            <div className="flex items-baseline gap-3">
              <span className="text-[0.68rem] font-semibold tracking-[0.14em] uppercase text-[var(--color-muted)]">
                Stage 01
              </span>
              <h2
                className="text-lg font-[560] text-[var(--color-ink)]"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Prepare
              </h2>
            </div>
            <OutputPathForm
              outputFolder={outputFolder}
              onOutputFolderChange={handleOutputFolderChange}
              disabled={processing}
            />
            <UploadZone onFilesSelected={handleFilesSelected} disabled={processing} />
          </section>

          {selectionMessage && <div className="alert alert-warn">{selectionMessage}</div>}

          {selectedFiles.length > 0 && (
            <div
              className={`panel ${
                processing ? 'sticky top-3 z-20 ring-1 ring-[rgba(15,118,110,0.18)]' : ''
              }`}
            >
              <div className="flex items-center justify-between gap-3 mb-3 flex-wrap">
                <div>
                  <h3 className="panel-title text-[1.05rem]">Ready queue</h3>
                  <p className="panel-subtitle">
                    {selectedFiles.length} supported file{selectedFiles.length === 1 ? '' : 's'} selected
                  </p>
                </div>
                <span className="text-xs font-semibold text-[var(--color-accent)] bg-[var(--color-accent-soft)] px-2.5 py-1 rounded-md">
                  Stage 02 ready
                </span>
              </div>

              <div className="flex flex-wrap gap-2 mb-4 max-h-28 overflow-auto">
                {selectedFiles.map((f) => (
                  <div key={`${f.name}-${f.size}-${f.lastModified}`} className="file-chip" title={f.name}>
                    <span>{f.name}</span>
                    <span className="text-[var(--color-muted)]">{formatBytes(f.size)}</span>
                  </div>
                ))}
              </div>

              {!outputFolder.trim() && (
                <div className="alert alert-warn mb-3">
                  Enter an output folder path above to enable Start OCR.
                </div>
              )}

              <button
                type="button"
                onClick={handleStartOcr}
                disabled={!canStart}
                className="btn-primary w-full py-3"
              >
                {processing ? 'Processing…' : 'Start OCR'}
              </button>

              {processing && (
                <div ref={progressSectionRef} className="mt-4 pt-4 border-t border-[var(--color-line)]">
                  <ProgressBar processing progress={progress} />
                </div>
              )}
            </div>
          )}

          <section className="space-y-3">
            <div className="flex items-baseline gap-3">
              <span className="text-[0.68rem] font-semibold tracking-[0.14em] uppercase text-[var(--color-muted)]">
                Stage 02
              </span>
              <h2
                className="text-lg font-[560] text-[var(--color-ink)]"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                OCR
              </h2>
            </div>
            <ProcessingStatus
              processing={false}
              progress={progress}
              result={result}
              error={error}
            />
            <ResultsViewer result={result} />
          </section>

          <section className="space-y-3">
            <div className="flex items-baseline gap-3">
              <span className="text-[0.68rem] font-semibold tracking-[0.14em] uppercase text-[var(--color-muted)]">
                Stage 03
              </span>
              <h2
                className="text-lg font-[560] text-[var(--color-ink)]"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Report
              </h2>
            </div>
            <ReportPanel mdFolder={outputFolder} disabled={processing} />
          </section>

          <JobHistory refreshKey={refreshKey} />
        </div>
      </main>
    </div>
  );
}
