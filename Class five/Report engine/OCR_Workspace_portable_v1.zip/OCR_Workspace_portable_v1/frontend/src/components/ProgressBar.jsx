function stageLabel(stage) {
  switch (stage) {
    case 'uploading':
      return 'Uploading';
    case 'queued':
      return 'Queued';
    case 'processing':
      return 'Processing';
    case 'exporting':
      return 'Saving';
    case 'completed':
      return 'Completed';
    case 'failed':
      return 'Failed';
    default:
      return 'Working';
  }
}

export default function ProgressBar({
  progress,
  processing = false,
  complete = false,
  className = '',
}) {
  const percent = complete
    ? 100
    : Math.max(progress?.percent ?? 0, processing ? 5 : 0);
  const message =
    progress?.message ||
    (processing ? 'Starting OCR…' : complete ? 'OCR job completed' : '');

  return (
    <div className={`space-y-3 ${className}`.trim()}>
      <div className="flex items-center justify-between text-sm gap-3">
        <span className="font-semibold text-[var(--color-ink-soft)] truncate">
          {stageLabel(progress?.stage || (complete ? 'completed' : 'processing'))}
          {progress?.current_filename ? `: ${progress.current_filename}` : ''}
        </span>
        <span className="text-[var(--color-muted)] shrink-0 tabular-nums font-medium">
          {percent}%
        </span>
      </div>

      <div className="h-2.5 w-full rounded-full bg-[var(--color-paper-deep)] overflow-hidden relative">
        <div
          className={`h-full rounded-full transition-all duration-500 ease-out ${
            complete ? 'bg-[var(--color-ok)]' : 'bg-[var(--color-accent)]'
          }`}
          style={{ width: `${percent}%` }}
        />
        {processing && !complete && (
          <div className="pointer-events-none absolute inset-0 overflow-hidden rounded-full">
            <div className="ocr-progress-shine h-full w-1/3 bg-white/30" />
          </div>
        )}
      </div>

      {message && <p className="text-sm text-[var(--color-muted)]">{message}</p>}

      {progress?.total_files > 0 && (
        <p className="text-xs text-[var(--color-muted)]">
          File {Math.max(progress.current_file || 0, 0)} of {progress.total_files}
          {progress.current_page && progress.total_pages > 1
            ? ` · Page ${progress.current_page} of ${progress.total_pages}`
            : ''}
        </p>
      )}
    </div>
  );
}
