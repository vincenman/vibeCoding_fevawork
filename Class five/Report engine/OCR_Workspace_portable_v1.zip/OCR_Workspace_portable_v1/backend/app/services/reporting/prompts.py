"""OCR report extraction prompts and field definitions."""

SYSTEM_PROMPT = """
You extract structured invoice data from OCR Markdown.

Return ONLY a single JSON object (no markdown fences, no commentary) with
exactly these keys, in this order. Use an empty string if a value is missing.

{
  "source_filename": "original markdown file name",
  "supplier_name": "vendor / seller legal or trading name",
  "supplier_address": "full supplier address",
  "supplier_phone": "supplier telephone",
  "supplier_email": "supplier email",
  "invoice_no": "invoice number",
  "issue_date": "invoice issue date as written",
  "po_number": "purchase order number",
  "due_date": "payment due date as written",
  "payment_terms": "payment terms",
  "currency": "ISO currency code if present, else as written",
  "bill_to_name": "bill-to company or person",
  "bill_to_address": "full bill-to address",
  "bill_to_uen": "bill-to UEN / tax / registration id",
  "ship_to_name": "ship-to company or location name",
  "ship_to_address": "full ship-to address",
  "ship_to_contact": "ship-to contact name and phone",
  "subtotal": "subtotal amount with currency if shown",
  "gst_rate": "GST / VAT rate",
  "gst_amount": "GST / VAT amount with currency if shown",
  "total_due": "total amount due with currency if shown",
  "bank_name": "remittance bank name",
  "account_name": "bank account name",
  "account_no": "bank account number",
  "swift_code": "SWIFT / BIC",
  "line_items": "semicolon-separated line items as: qty x description @ unit = amount"
}

Rules:
- Copy values from the document; do not invent data.
- Keep numbers and dates as they appear.
- line_items must be a single string, not an array.
""".strip()

EXTRACT_FIELDS = [
    "source_filename",
    "supplier_name",
    "supplier_address",
    "supplier_phone",
    "supplier_email",
    "invoice_no",
    "issue_date",
    "po_number",
    "due_date",
    "payment_terms",
    "currency",
    "bill_to_name",
    "bill_to_address",
    "bill_to_uen",
    "ship_to_name",
    "ship_to_address",
    "ship_to_contact",
    "subtotal",
    "gst_rate",
    "gst_amount",
    "total_due",
    "bank_name",
    "account_name",
    "account_no",
    "swift_code",
    "line_items",
]
