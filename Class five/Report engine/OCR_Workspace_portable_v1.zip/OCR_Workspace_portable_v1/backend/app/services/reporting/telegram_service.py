"""Optional Telegram delivery for OCR Excel reports (soft-fail)."""

from __future__ import annotations

from pathlib import Path

from telegram import Bot
from telegram.error import TelegramError

from app.config import settings


async def send_excel_via_telegram(
    excel_path: Path,
    row_count: int,
    token: str | None = None,
    chat_id: str | None = None,
) -> tuple[bool, str]:
    """
    Send the Excel file via Telegram.
    Returns (sent, message). Never raises for missing credentials or API errors.
    """
    resolved_token = (token or settings.telegram_bot_token or "").strip()
    resolved_chat_id = str(chat_id or settings.telegram_chat_id or "").strip()

    if not resolved_token or not resolved_chat_id:
        return (
            False,
            "Telegram skipped: missing bot token or chat ID. Excel file was still saved.",
        )

    caption = (
        f"OCR report ready: {excel_path.name}\n"
        f"Rows extracted: {row_count}"
    )

    try:
        bot = Bot(token=resolved_token)
        async with bot:
            with excel_path.open("rb") as document:
                await bot.send_document(
                    chat_id=resolved_chat_id,
                    document=document,
                    filename=excel_path.name,
                    caption=caption,
                )
        return True, f"Telegram: sent {excel_path.name} to chat {resolved_chat_id}"
    except (TelegramError, OSError, ValueError, RuntimeError) as exc:
        return False, f"Telegram skipped: send failed ({exc}). Excel file was still saved."
    except Exception as exc:  # noqa: BLE001 — soft-fail per requirement
        return (
            False,
            f"Telegram skipped: unexpected error ({exc}). Excel file was still saved.",
        )
