"""LLM field extraction from OCR Markdown."""

from __future__ import annotations

import json
import re
from pathlib import Path

from openai import AzureOpenAI

from app.config import settings
from app.services.reporting.prompts import EXTRACT_FIELDS, SYSTEM_PROMPT


def get_azure_client() -> tuple[AzureOpenAI, str]:
    if not settings.azure_openai_api_key or not settings.azure_openai_endpoint:
        raise RuntimeError(
            "Missing AZURE_OPENAI_API_KEY or AZURE_OPENAI_ENDPOINT in environment"
        )

    client = AzureOpenAI(
        api_key=settings.azure_openai_api_key,
        azure_endpoint=settings.azure_endpoint_normalized,
        api_version=settings.azure_openai_api_version,
    )
    return client, settings.effective_model


def parse_json_object(text: str) -> dict:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    return json.loads(cleaned)


def extract_fields_from_md(
    client: AzureOpenAI,
    model: str,
    md_path: Path,
    system_prompt: str = SYSTEM_PROMPT,
    fields: list[str] | None = None,
) -> dict[str, str]:
    field_list = fields or EXTRACT_FIELDS
    markdown = md_path.read_text(encoding="utf-8")
    user_message = (
        f"Source filename: {md_path.name}\n\n"
        f"OCR Markdown:\n{markdown}"
    )

    response = client.chat.completions.create(
        model=model,
        temperature=0,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ],
    )
    content = (response.choices[0].message.content or "").strip()
    data = parse_json_object(content)
    data["source_filename"] = data.get("source_filename") or md_path.name
    return {field: str(data.get(field, "") or "") for field in field_list}
