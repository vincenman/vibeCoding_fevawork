import { useCallback, useRef, useState } from 'react';

export default function UploadZone({ onFilesSelected, disabled }) {
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef(null);
  const folderInputRef = useRef(null);

  const handleFiles = useCallback(
    (fileList) => {
      const files = Array.from(fileList);
      if (files.length > 0) onFilesSelected(files);
    },
    [onFilesSelected],
  );

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    if (!disabled) handleFiles(e.dataTransfer.files);
  };

  return (
    <section className="panel">
      <h2 className="panel-title">Upload documents</h2>
      <p className="panel-subtitle mb-4">
        Drop invoices or scans here, or select files and folders from disk.
      </p>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        className={`rounded-2xl border-2 border-dashed px-6 py-12 text-center transition-colors duration-200 ${
          dragOver
            ? 'border-[var(--color-accent)] bg-[var(--color-accent-soft)]'
            : 'border-[var(--color-line)] bg-[var(--color-paper)]'
        } ${disabled ? 'opacity-50 pointer-events-none' : ''}`}
      >
        <div
          className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl border border-[var(--color-line)] bg-white text-[var(--color-accent)]"
          aria-hidden
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M12 16V4m0 0l-4 4m4-4l4 4" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M4 14v4a2 2 0 002 2h12a2 2 0 002-2v-4" strokeLinecap="round" />
          </svg>
        </div>
        <p className="text-[var(--color-ink-soft)] font-medium mb-1">
          Drag and drop images or PDFs
        </p>
        <p className="text-xs text-[var(--color-muted)] mb-5">
          PNG, JPG, WEBP, TIFF, PDF
        </p>
        <div className="flex justify-center gap-3 flex-wrap">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={disabled}
            className="btn-primary"
          >
            Select files
          </button>
          <button
            type="button"
            onClick={() => folderInputRef.current?.click()}
            disabled={disabled}
            className="btn-secondary"
          >
            Select folder
          </button>
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept=".png,.jpg,.jpeg,.webp,.tiff,.tif,.pdf,image/*,application/pdf"
        className="hidden"
        onChange={(e) => {
          handleFiles(e.target.files);
          e.target.value = '';
        }}
      />
      <input
        ref={folderInputRef}
        type="file"
        webkitdirectory=""
        directory=""
        multiple
        className="hidden"
        onChange={(e) => {
          handleFiles(e.target.files);
          e.target.value = '';
        }}
      />
    </section>
  );
}
