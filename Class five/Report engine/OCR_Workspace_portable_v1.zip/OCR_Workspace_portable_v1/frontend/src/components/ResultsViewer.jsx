import { useState } from 'react';
import ReactMarkdown from 'react-markdown';

function downloadText(content, filename) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export default function ResultsViewer({ result }) {
  const [activeTab, setActiveTab] = useState('text');
  const [selectedFileIdx, setSelectedFileIdx] = useState(0);

  if (!result || !result.files?.length) return null;

  const file = result.files[selectedFileIdx] || result.files[0];
  const allText = result.files
    .filter((f) => f.success && f.text)
    .map((f) => `# ${f.filename}\n\n${f.text}`)
    .join('\n\n---\n\n');

  const tabs = [
    { id: 'text', label: 'Plain text' },
    { id: 'markdown', label: 'Markdown' },
    { id: 'json', label: 'JSON' },
  ];

  const copyToClipboard = async (text) => {
    await navigator.clipboard.writeText(text);
  };

  return (
    <section className="panel workspace-enter">
      <div className="flex items-start justify-between gap-3 mb-4 flex-wrap">
        <div>
          <h2 className="panel-title">OCR results</h2>
          <p className="panel-subtitle">Review extracted text before generating the Excel report.</p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => copyToClipboard(file.text || '')}
            className="btn-ghost"
          >
            Copy
          </button>
          <button
            type="button"
            onClick={() => downloadText(allText, 'ocr_results.md')}
            className="btn-ghost"
          >
            Download .md
          </button>
        </div>
      </div>

      {result.files.length > 1 && (
        <div className="flex flex-wrap gap-2 mb-4">
          {result.files.map((f, idx) => (
            <button
              key={f.filename + idx}
              type="button"
              onClick={() => setSelectedFileIdx(idx)}
              className={`px-3 py-1.5 text-xs rounded-lg border font-medium transition-colors ${
                idx === selectedFileIdx
                  ? 'bg-[var(--color-accent-soft)] border-[var(--color-accent)] text-[var(--color-accent)]'
                  : 'bg-[var(--color-paper)] border-[var(--color-line)] text-[var(--color-muted)]'
              }`}
            >
              {f.filename} {f.success ? '· ok' : '· failed'}
            </button>
          ))}
        </div>
      )}

      <div className="flex border-b border-[var(--color-line)] mb-4 gap-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`px-3 py-2 text-sm font-semibold border-b-2 -mb-px transition-colors ${
              activeTab === tab.id
                ? 'border-[var(--color-accent)] text-[var(--color-accent)]'
                : 'border-transparent text-[var(--color-muted)] hover:text-[var(--color-ink-soft)]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {!file.success && (
        <div className="alert alert-danger">
          Error processing {file.filename}: {file.error}
        </div>
      )}

      {file.success && activeTab === 'text' && (
        <pre className="text-sm text-[var(--color-ink-soft)] whitespace-pre-wrap bg-[var(--color-paper)] rounded-xl p-4 max-h-96 overflow-auto border border-[var(--color-line)]">
          {file.text}
        </pre>
      )}

      {file.success && activeTab === 'markdown' && (
        <div className="markdown-preview text-sm text-[var(--color-ink-soft)] bg-[var(--color-paper)] rounded-xl p-4 max-h-96 overflow-auto border border-[var(--color-line)]">
          <ReactMarkdown>{file.text}</ReactMarkdown>
        </div>
      )}

      {activeTab === 'json' && (
        <pre className="text-sm text-[var(--color-ink-soft)] whitespace-pre-wrap bg-[var(--color-paper)] rounded-xl p-4 max-h-96 overflow-auto border border-[var(--color-line)]">
          {JSON.stringify(result, null, 2)}
        </pre>
      )}
    </section>
  );
}
