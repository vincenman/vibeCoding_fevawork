import ProgressBar from './ProgressBar';

export default function ProcessingStatus({ processing, progress, result, error }) {
  if (!processing && !result && !error) return null;

  return (
    <section
      className={`panel ${
        processing ? 'sticky top-3 z-20 ring-1 ring-[rgba(15,118,110,0.2)]' : ''
      } ${result && !processing ? 'success-pulse' : ''}`}
    >
      <h2 className="panel-title mb-4">Processing status</h2>

      {processing && <ProgressBar processing progress={progress} />}

      {error && <div className="alert alert-danger">{error}</div>}

      {result && !processing && (
        <div className="space-y-3">
          <ProgressBar complete progress={progress || { stage: 'completed', percent: 100 }} />

          <div className="alert alert-ok">
            Job <code className="font-mono text-[0.8rem]">{result.job_id.slice(0, 8)}…</code>{' '}
            completed
            {result.md_files?.length > 0 && (
              <div className="mt-2 space-y-1">
                <p className="font-medium">Markdown files saved</p>
                <ul className="space-y-1">
                  {result.md_files.map((path) => (
                    <li key={path} className="font-mono text-[0.75rem] break-all">
                      {path}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {result.export_error && (
            <div className="alert alert-warn">
              Export warning: {result.export_error}. OCR text is still available below.
            </div>
          )}
        </div>
      )}
    </section>
  );
}
