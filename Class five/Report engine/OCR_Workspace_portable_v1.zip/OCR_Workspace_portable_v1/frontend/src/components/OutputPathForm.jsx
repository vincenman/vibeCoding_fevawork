import { useState } from 'react';
import { browseOutputFolder, validateOutputPath } from '../api/client';

export default function OutputPathForm({ outputFolder, onOutputFolderChange, disabled }) {
  const [pathStatus, setPathStatus] = useState(null);
  const [validating, setValidating] = useState(false);
  const [browsing, setBrowsing] = useState(false);

  const handleValidate = async () => {
    if (!outputFolder.trim()) {
      setPathStatus({ valid: false, error: 'Path is required' });
      return;
    }
    setValidating(true);
    try {
      const result = await validateOutputPath(outputFolder);
      setPathStatus(result);
    } catch {
      setPathStatus({ valid: false, error: 'Validation request failed' });
    } finally {
      setValidating(false);
    }
  };

  const handleBrowse = async () => {
    setBrowsing(true);
    setPathStatus(null);
    try {
      const result = await browseOutputFolder();
      if (result.cancelled) return;
      if (result.error) {
        setPathStatus({ valid: false, error: result.error });
        return;
      }
      if (result.folder_path) {
        onOutputFolderChange(result.folder_path);
        setPathStatus({ valid: true, resolved_path: result.folder_path });
      }
    } catch (err) {
      setPathStatus({ valid: false, error: err.message });
    } finally {
      setBrowsing(false);
    }
  };

  return (
    <section className="panel">
      <h2 className="panel-title">Output location</h2>
      <p className="panel-subtitle mb-4">
        Choose where Markdown results will be saved. Browse opens a folder picker on this machine.
      </p>

      <div>
        <label
          htmlFor="output-folder"
          className="block text-sm font-medium text-[var(--color-ink-soft)] mb-1.5"
        >
          Output folder path
        </label>
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            id="output-folder"
            type="text"
            value={outputFolder}
            onChange={(e) => {
              onOutputFolderChange(e.target.value);
              setPathStatus(null);
            }}
            placeholder="/home/user/ocr_output or C:\OCR_Results"
            disabled={disabled}
            className="field-input flex-1"
          />
          <div className="flex gap-2 shrink-0">
            <button
              type="button"
              onClick={handleBrowse}
              disabled={disabled || browsing}
              className="btn-primary whitespace-nowrap"
            >
              {browsing ? 'Opening…' : 'Browse…'}
            </button>
            <button
              type="button"
              onClick={handleValidate}
              disabled={disabled || validating || !outputFolder.trim()}
              className="btn-secondary whitespace-nowrap"
            >
              {validating ? 'Checking…' : 'Validate'}
            </button>
          </div>
        </div>
        {pathStatus && (
          <p
            className={`mt-2 text-sm ${
              pathStatus.valid ? 'text-[var(--color-ok)]' : 'text-[var(--color-danger)]'
            }`}
          >
            {pathStatus.valid ? `Valid: ${pathStatus.resolved_path}` : pathStatus.error}
          </p>
        )}
      </div>
    </section>
  );
}
