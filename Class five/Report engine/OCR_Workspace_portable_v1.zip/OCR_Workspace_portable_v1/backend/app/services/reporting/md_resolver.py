"""Resolve Markdown input files for the reporting engine."""

from pathlib import Path


def resolve_md_files(folder: Path, filenames: list[str] | None = None) -> list[Path]:
    if not folder.exists():
        raise FileNotFoundError(f"MD folder not found: {folder}")
    if not folder.is_dir():
        raise NotADirectoryError(f"MD folder path is not a directory: {folder}")

    names = filenames or []
    if names:
        paths = [folder / name for name in names]
        missing = [str(path) for path in paths if not path.exists()]
        if missing:
            raise FileNotFoundError(
                "Input Markdown file(s) not found: " + ", ".join(missing)
            )
        return paths

    paths = sorted(folder.glob("*.md"))
    if not paths:
        raise FileNotFoundError(f"No .md files found in folder: {folder}")
    return paths
